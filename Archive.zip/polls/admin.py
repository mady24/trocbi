from django.contrib import admin

from .models import *


admin.site.register(NatureBien)
admin.site.register(SousFamille)
admin.site.register(PostProp)
admin.site.register(PostSearch)
admin.site.register(Profile)
admin.site.register(Avatar)

# Register your models here.
